package com.lowongankerja.data.model

data class LoginRequest(
    val email: String,
    val password: String
)

data class LoginResponse(
    val token: String?,
    val error: String?
)

data class RegisterRequest(
    val email: String,
    val password: String
)

data class RegisterResponse(
    val id: Int?,
    val token: String?,
    val error: String?
)

data class Job(
    val id: Int,
    val title: String,
    val company: String,
    val location: String,
    val salary: String?
)