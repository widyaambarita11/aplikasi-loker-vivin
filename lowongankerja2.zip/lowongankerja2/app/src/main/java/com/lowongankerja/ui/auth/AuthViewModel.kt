package com.lowongankerja.ui.auth

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.lowongankerja.data.model.*
import com.lowongankerja.data.repository.AuthRepository
import kotlinx.coroutines.launch

class AuthViewModel(private val repository: AuthRepository) : ViewModel() {
    private val _loginResult = MutableLiveData<LoginResponse?>()
    val loginResult: LiveData<LoginResponse?> = _loginResult

    private val _registerResult = MutableLiveData<RegisterResponse?>()
    val registerResult: LiveData<RegisterResponse?> = _registerResult

    private val _error = MutableLiveData<String?>()
    val error: LiveData<String?> = _error

    fun login(email: String, password: String) {
        viewModelScope.launch {
            try {
                _loginResult.postValue(repository.login(email, password))
            } catch (e: Exception) {
                _error.postValue(e.message ?: "Login gagal")
            }
        }
    }

    fun register(email: String, password: String) {
        viewModelScope.launch {
            try {
                _registerResult.postValue(repository.register(email, password))
            } catch (e: Exception) {
                _error.postValue(e.message ?: "Registrasi gagal")
            }
        }
    }
}