package com.lowongankerja.data.repository

import com.lowongankerja.data.model.LoginResponse
import com.lowongankerja.data.model.RegisterResponse

class AuthRepository {

    // Login lokal: Menerima email dan password APA SUSAH/APAPUN
    suspend fun login(email: String, password: String): LoginResponse {
        // Simulasi token berhasil dibuat dari email user
        val fakeToken = "token_lokal_${email.replace("@", "_")}"
        return LoginResponse(token = fakeToken, error = null)
    }

    // Register lokal: Menerima email dan password APA SAJA
    suspend fun register(email: String, password: String): RegisterResponse {
        val fakeToken = "token_lokal_${email.replace("@", "_")}"
        return RegisterResponse(id = 1, token = fakeToken, error = null)
    }
}